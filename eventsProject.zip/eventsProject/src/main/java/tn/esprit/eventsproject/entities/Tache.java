package tn.esprit.eventsproject.entities;

public enum Tache {
    INVITE, ORGANISATEUR,SERVEUR,ANIMATEUR
}
